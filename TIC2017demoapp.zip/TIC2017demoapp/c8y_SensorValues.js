var cepObject = {
    cepMessages: function (msg) {
      $('#cep_messages').prepend(msg);
    },
    /*
     * parses the long-polling data stream
     */
    parseDataStream: function(data) {'use strict';

        // Append CEP Message
        cepObject.cepMessages('<div class="alert alert-success" role="alert">Received: '+JSON.stringify(data)+'</div>');

        var i, record, id, type, measurement, object, now, date;
        for (i = 0; i < data.length; i += 1) {
          // ignore the 'success' array element
          if (typeof data[i].data !== 'undefined') {
            record = data[i].data.data;
            console.log(record);

            // parse for measurement channel data
            if (data[i].channel.indexOf('measurements') > -1) {
              type = record.type;
              console.log(type);
              if (type === "SensorMeasurement") {
                if (typeof record["TemperatureMeasurement"] !== 'undefined') {
                  cepObject.chartData.setValue(0, 1, record["TemperatureMeasurement"]['IoT Board Temperature'].value);
                  cepObject.chart.draw(cepObject.chartData, cepObject.chartOptions);                  
                }
                else if (typeof record["LightMeasurement"] !== 'undefined') {
                  cepObject.chartData.setValue(1, 1, record["LightMeasurement"]['Light Level'].value);
                  cepObject.chart.draw(cepObject.chartData, cepObject.chartOptions);                  
                }
				else if (typeof record["AccelerationMeasurement"] !== 'undefined') {
				  if (typeof record["AccelerationMeasurement"]['X'] !== 'undefined') {
                    cepObject.chartDataAcc.setValue(0, 1, record["AccelerationMeasurement"]['X'].value);
                    cepObject.chartAcc.draw(cepObject.chartDataAcc, cepObject.chartOptionsAcc);                  
                  }
                  else if (typeof record["AccelerationMeasurement"]['Y'] !== 'undefined') {
                    cepObject.chartDataAcc.setValue(1, 1, record["AccelerationMeasurement"]['Y'].value);
                    cepObject.chartAcc.draw(cepObject.chartDataAcc, cepObject.chartOptionsAcc);                  
                  }
                  else if (typeof record["AccelerationMeasurement"]['Z'] !== 'undefined') {
                    cepObject.chartDataAcc.setValue(2, 1, record["AccelerationMeasurement"]['Z'].value);
                    cepObject.chartAcc.draw(cepObject.chartDataAcc, cepObject.chartOptionsAcc);                  
                  }
				}
			  }
			}
          }
        }
    },
    /*
     * long-polling to continuously get data - requires the API url and clientId
     */
    longPolling: function(url, clientId) {'use strict';
        var i, data = {
            "channel": "/meta/connect",
            "connectionType": "long-polling",
            "clientId": clientId
        };
        // connect to get messages
        $.ajax({
            url: url,
            type: 'POST',
            headers: { 
                "Authorization": 'Basic XXXXXXXXXXXXXXXXXXXXXXXXX'
            },
            contentType: 'application/json',
            dataType: 'json',
            data: JSON.stringify(data),
            success: function(data, status, jqXHR) {
                //console.log(data);
                cepObject.parseDataStream(data);
                //cepObject.longPolling(clientId);
            },
            error: function(jqXHR, status, error) {
                console.log(status + ", " + error);
                console.log(jqXHR);
            },
            complete: function() {
                cepObject.longPolling(url, clientId);
            },
            timeout: 30000
        });
    },
    /*
     * sets up the subscription to a particular channel
    *      - requires API url, clientID and channel name to subscribe to
     */
    setupSubscription: function(url, channel, clientId, callback) {'use strict';
        var clientId, headers = { 
            Authorization: 'Basic XXXXXXXXXXXXXXXXXXXXXXXXX'
        }, data = {
            "channel": "/meta/subscribe",
            "subscription": channel,
            "clientId": clientId
        };
        $.ajax({
            url: url,
            type: 'POST',
            headers: headers,
            contentType: 'application/json',
            dataType: 'json',
            data: JSON.stringify(data),
            success: function(data, status, jqXHR) {
                callback();
            },
            error: function(jqXHR, status, error) {
                console.log(status + ", " + error);
                console.log(jqXHR);
            }
        });
    },
    /*
     * setups the handshake for real time streaming/notifications to get the clientId
     */
    setupHandShake: function(url, callback) {'use strict';
        var obj, clientId, headers = { 
            Authorization: 'Basic XXXXXXXXXXXXXXXXXXXXXXXXX'
        }, data = {
            "version": "1.0",
            "minimumVersion": "0.9",
            "channel": "/meta/handshake",
            "supportedConnectionTypes": ["long-polling"],
            "advice": {
                "timeout": 60000, "interval": 0
            }
        };
        $.ajax({
            url: url,
            type: 'POST',
            headers: headers,
            contentType: 'application/json',
            dataType: 'json',
            data: JSON.stringify(data),
            success: function(data, status, jqXHR) {
                clientId = data[0].clientId;
                obj = {
                    "clientId": clientId,
                    "url": url
                };
                callback(clientId);
            },
            error: function(jqXHR, status, error) {
                console.log(status + ", " + error);
                console.log(jqXHR);
            }
        });
    },
    /*
     * setups the web sockets for the real time data streams (for both normal 
     * records as well as alarms)
     */
    dataStreamSetup: function() {'use strict';
      var urlRealTime = "https://tic2017team000.iot.telstra.com/cep/realtime",
          channels = [
              "/measurements/*"
          ], i, clientId;

      // handshake
      cepObject.setupHandShake(urlRealTime, function(id) {
          clientId = id;
          // subscribe to the channels
          for (i = 0; i < channels.length; i += 1) {
              cepObject.setupSubscription(urlRealTime, channels[i], clientId, function() {
                  console.log("Success subscribing to channel: " + channels[i]);
              });
          }
          // start long-polling
          cepObject.longPolling(urlRealTime, clientId);
      });
    },
    chartData: google.visualization.arrayToDataTable([
      ['Label', 'Value'],
      ['Temp Board', 0],
      ['Light Level', 0]
    ]),
    chartDataAcc: google.visualization.arrayToDataTable([
      ['Label', 'Value'],
      ['Acc X', 0],
      ['Acc Y', 0],
      ['Acc Z', 0]
    ]),
    chartOptions: {
      max: 60, min: 0,
      width: 800, height: 240,
      redFrom: 40, redTo: 60,
      yellowFrom: 20, yellowTo: 40,
      minorTicks: 5
    },
    chartOptionsAcc: {
      max: 15, min: -15,
      width: 800, height: 240,
      redFrom: 0, redTo: 15,
      yellowFrom:-15, yellowTo: 0,
      minorTicks: 5
    },
    chart: new google.visualization.Gauge(document.getElementById('chart_div')),
	chartAcc: new google.visualization.Gauge(document.getElementById('chart_div2'))
};

// Begin longpoll setup
cepObject.dataStreamSetup();

// Begin Google Gauge Setup
google.setOnLoadCallback(drawChart);
function drawChart() {
  cepObject.chart.draw(cepObject.chartData, cepObject.chartOptions);
  cepObject.chartAcc.draw(cepObject.chartDataAcc, cepObject.chartOptionsAcc);
}